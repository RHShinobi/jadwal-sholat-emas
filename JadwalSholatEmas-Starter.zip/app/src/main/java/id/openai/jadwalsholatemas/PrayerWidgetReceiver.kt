package id.openai.jadwalsholatemas

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class PrayerWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("prayer_prefs", Context.MODE_PRIVATE)
        val lat = prefs.getString("lat", "-6.2")?.toDoubleOrNull() ?: -6.2
        val lon = prefs.getString("lon", "106.8")?.toDoubleOrNull() ?: 106.8
        val rows = runCatching { PrayerData.today(lat, lon) }.getOrNull()
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_loading)
            val text = buildString {
                append("JADWAL SHOLAT • EMAS\n")
                if (rows == null) append("Buka aplikasi untuk memuat jadwal")
                else rows.forEach { append(it.name).append("  ").append(PrayerData.format(it.time)).append("\n") }
            }
            views.setTextViewText(android.R.id.text1, text)
            manager.updateAppWidget(id, views)
        }
    }
}
