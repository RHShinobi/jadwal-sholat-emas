package id.openai.jadwalsholatemas

import com.batoulapps.adhan2.CalculationMethod
import com.batoulapps.adhan2.CalculationParameters
import com.batoulapps.adhan2.Coordinates
import com.batoulapps.adhan2.PrayerTimes
import com.batoulapps.adhan2.Madhab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.*

data class Prayer(val name: String, val time: Date)

object PrayerData {
    fun today(lat: Double, lon: Double): List<Prayer> {
        val coords = Coordinates(lat, lon)
        val params: CalculationParameters = CalculationMethod.MUSLIM_WORLD_LEAGUE.parameters
        params.madhab = Madhab.SHAFI
        val times = PrayerTimes(coords, java.time.LocalDate.now(), params)
        return listOf(
            Prayer("Subuh", times.fajr),
            Prayer("Dzuhur", times.dhuhr),
            Prayer("Ashar", times.asr),
            Prayer("Maghrib", times.maghrib),
            Prayer("Isya", times.isha)
        )
    }
    fun format(date: Date): String = SimpleDateFormat("HH:mm", Locale("id", "ID")).format(date)
    fun qiblaBearing(lat: Double, lon: Double): Double {
        val kaabaLat = Math.toRadians(21.4225)
        val kaabaLon = Math.toRadians(39.8262)
        val userLat = Math.toRadians(lat)
        val dLon = kaabaLon - Math.toRadians(lon)
        val y = sin(dLon)
        val x = cos(userLat) * tan(kaabaLat) - sin(userLat) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }
}
