package id.openai.jadwalsholatemas

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import java.util.Date

private val Black = Color(0xFF111111)
private val Panel = Color(0xFF1D1D1D)
private val Gold = Color(0xFFD8B45A)
private val Cream = Color(0xFFF4E8C8)

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) fetchLocation()
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prayer_prefs", MODE_PRIVATE)
        setContent {
            var lat by remember { mutableStateOf(prefs.getString("lat", "-6.2") ?: "-6.2") }
            var lon by remember { mutableStateOf(prefs.getString("lon", "106.8") ?: "106.8") }
            var locationLabel by remember { mutableStateOf("Lokasi awal: Jakarta (dapat diubah)") }
            var refresh by remember { mutableIntStateOf(0) }
            val latitude = lat.toDoubleOrNull()?.coerceIn(-90.0, 90.0) ?: -6.2
            val longitude = lon.toDoubleOrNull()?.coerceIn(-180.0, 180.0) ?: 106.8
            val prayers = remember(latitude, longitude, refresh) { runCatching { PrayerData.today(latitude, longitude) }.getOrElse { emptyList() } }
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel, onSurface = Cream)) {
                Surface(Modifier.fillMaxSize(), color = Black) {
                    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Text("JADWAL SHOLAT", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text("Emas", color = Cream, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Text("Waktu ibadah Anda, dalam ketenangan.", color = Color.LightGray, fontSize = 14.sp)
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(locationLabel, color = Gold, fontSize = 13.sp)
                                    Text("Koordinat lokasi", color = Cream, fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(lat, { lat = it }, label = { Text("Latitude") }, modifier = Modifier.weight(1f), singleLine = true)
                                        OutlinedTextField(lon, { lon = it }, label = { Text("Longitude") }, modifier = Modifier.weight(1f), singleLine = true)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            prefs.edit().putString("lat", lat).putString("lon", lon).apply()
                                            refresh++
                                            locationLabel = "Lokasi tersimpan"
                                            updateWidget()
                                        }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("Simpan lokasi") }
                                        OutlinedButton(onClick = { requestLocation() }) {
                                            Icon(Icons.Default.LocationOn, null); Text(" GPS")
                                        }
                                    }
                                }
                            }
                        }
                        item { Text("JADWAL HARI INI", color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                        if (prayers.isEmpty()) item { Text("Jadwal belum dapat dihitung. Periksa koordinat dan koneksi sinkronisasi Gradle.", color = Cream) }
                        items(prayers) { prayer ->
                            val next = prayer.time.after(Date())
                            Card(colors = CardDefaults.cardColors(containerColor = if (next) Color(0xFF292417) else Panel), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(prayer.name, color = Cream, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                        if (next) Text("Waktu berikutnya", color = Gold, fontSize = 12.sp)
                                    }
                                    Text(PrayerData.format(prayer.time), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        item {
                            val bearing = PrayerData.qiblaBearing(latitude, longitude)
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("ARAH KIBLAT", color = Gold, fontWeight = FontWeight.Bold)
                                    Text("${"%.1f".format(bearing)}° dari utara", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                    Text("Kompas arah kiblat memerlukan sensor magnetometer; angka ini adalah bearing berdasarkan koordinat.", color = Color.LightGray, fontSize = 12.sp)
                                }
                            }
                        }
                        item {
                            Button(onClick = {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                scheduleNextPrayer(prayers)
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) {
                                Icon(Icons.Default.NotificationsActive, null); Spacer(Modifier.width(8.dp)); Text("Aktifkan pengingat sholat")
                            }
                            Text("Pengingat awal menjadwalkan waktu sholat berikutnya. Pastikan izin notifikasi/alarm diizinkan di pengaturan Android.", color = Color.LightGray, fontSize = 12.sp)
                        }
                        item { Text("Metode awal: Muslim World League • Mazhab Syafi'i", color = Color.Gray, fontSize = 11.sp) }
                    }
                }
            }
        }
    }
    private fun requestLocation() {
        locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    private fun fetchLocation() {
        val client = LocationServices.getFusedLocationProviderClient(this)
        try {
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    getSharedPreferences("prayer_prefs", MODE_PRIVATE).edit().putString("lat", loc.latitude.toString()).putString("lon", loc.longitude.toString()).apply()
                    recreate()
                }
            }
        } catch (_: SecurityException) { }
    }
    private fun scheduleNextPrayer(prayers: List<Prayer>) {
        val next = prayers.firstOrNull { it.time.after(Date()) } ?: return
        val intent = Intent(this, PrayerAlarmReceiver::class.java).putExtra("prayer_name", next.name)
        val pending = PendingIntent.getBroadcast(this, next.name.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.time.time, pending)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, next.time.time, pending)
        } catch (_: SecurityException) {
            alarm.set(AlarmManager.RTC_WAKEUP, next.time.time, pending)
        }
    }
    private fun updateWidget() {
        val intent = Intent(this, PrayerWidgetReceiver::class.java).setAction(android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE)
        val ids = android.appwidget.AppWidgetManager.getInstance(this).getAppWidgetIds(android.content.ComponentName(this, PrayerWidgetReceiver::class.java))
        intent.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(intent)
    }
}
private fun Date.after(other: Date) = this.time > other.time
