# Jadwal Sholat Emas (starter Android)

Starter project Android berbahasa Indonesia dengan tema hitam-emas.

## Fitur dalam starter
- Jadwal Subuh, Dzuhur, Ashar, Maghrib, Isya dihitung lokal dengan library Adhan.
- Lokasi GPS (izin lokasi saat aplikasi dibuka) dan input koordinat manual untuk lokasi pilihan.
- Arah kiblat dihitung dari koordinat.
- Tombol untuk mengaktifkan pengingat notifikasi jadwal berikutnya.
- App Widget sederhana yang menampilkan jadwal hari ini.

## Catatan penting
- Ini starter untuk diuji dan dikembangkan, belum aplikasi produksi.
- Notifikasi adalah pengingat standar, bukan pemutaran audio azan penuh. Android membatasi alarm tepat waktu dan notifikasi; perilaku tergantung izin, versi Android, dan optimasi baterai perangkat.
- Widget diperbarui saat aplikasi dibuka atau ketika sistem meminta pembaruan. Untuk produksi, tambahkan pembaruan terjadwal dan penanganan reboot.
- Jadwal menggunakan metode Muslim World League sebagai default awal. Sesuaikan parameter dengan acuan resmi setempat (misalnya Bimas Islam/Kemenag RI), zona waktu, dan koreksi lokal sebelum dipakai sebagai rujukan ibadah.
- Uji hasil jadwal dengan sumber resmi di kota Anda.

## Cara membuka
1. Instal Android Studio versi stabil.
2. Buka folder `JadwalSholatEmas` di Android Studio.
3. Biarkan Gradle Sync selesai.
4. Jalankan di emulator atau HP Android dengan USB debugging.
5. Untuk APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Izin
Lokasi diminta saat pengguna menekan tombol lokasi. Notifikasi diminta pada Android 13+. Untuk distribusi, gunakan signing release dari Android Studio.
